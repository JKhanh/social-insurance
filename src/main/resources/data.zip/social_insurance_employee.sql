insert into social_insurance.employee (id, name, birthday, join_date, position, enterprise_id, address, salary, street)
values  (1, 'a', '2021-04-01', '2021-04-01', 'b', null, 'c', '1', 'd'),
        (2, 'b', '2021-01-13', '2021-03-18', 'c', null, 'Phường Điện Biên-Quận Ba Đình-Thành phố Hà Nội', '2000000', 'e'),
        (3, 'c', '1995-10-26', '2021-01-13', 'Khong co', null, 'Phường Điện Biên-Quận Ba Đình-Thành phố Hà Nội', '350000', '15 Tran Phu'),
        (4, 'd', '1990-09-20', '2021-01-13', 'Chu', null, 'Phường Điện Biên-Quận Ba Đình-Thành phố Hà Nội', '1250000', '16 Tran Phu'),
        (5, 'e', '1990-09-20', '2021-01-13', 'Chu', null, 'Xã Nàn Xỉn-Huyện Xín Mần-Tỉnh Hà Giang', '2000000', '11 abc');